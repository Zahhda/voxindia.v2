const mongoose = require("mongoose");

const OrderSchema = new mongoose.Schema({
  userId: { type: String, required: false, default: null },
  address: { type: Object, required: true },
  items: [
    {
      product: { type: mongoose.Schema.Types.ObjectId, ref: 'product' }, // Proper reference
      variant: String, // Added variant
      color: String, // Added color
      quantity: Number
    }
  ],
  paymentMethod: { type: String, required: true },
  amount: { type: Number, required: true },
  razorpayOrderId: String,
  razorpayPaymentId: String,
  razorpaySignature: String,
  status: { type: String, default: "Pending" },
  createdAt: { type: Date, default: Date.now },
});

export default mongoose.models.Order || mongoose.model("Order", OrderSchema);
