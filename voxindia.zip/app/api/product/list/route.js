import connectDB from "@/lib/db";
import Product from "@/models/Product";
import { NextResponse } from "next/server";

export async function GET(req) {
  await connectDB();
  
  const { searchParams } = new URL(req.url);
  const slug = searchParams.get('slug');

  let query = {};
  if (slug) query.slug = slug;

  const products = await Product.find(query);

  if (slug) {
    if (products.length === 0) {
      return NextResponse.json({ success: false, message: 'Product not found' }, { status: 404 });
    }
    return NextResponse.json(products[0]);
  }

  return NextResponse.json(products);
}
