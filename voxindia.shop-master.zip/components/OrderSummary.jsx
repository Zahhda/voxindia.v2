"use client";

import React, { useEffect, useState } from "react";
import { useAppContext } from "@/context/AppContext";
import toast from "react-hot-toast";

const OrderSummary = () => {
  const {
    router,
    getCartCount,
    getCartAmount,
    getToken,
    cartItems,
    setCartItems,
  } = useAppContext();

  const [showAddressModal, setShowAddressModal] = useState(false);
  const [selectedAddress, setSelectedAddress] = useState(null);
  const [savedAddresses, setSavedAddresses] = useState([]);
  const [loading, setLoading] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState("razorpay");

  const [addressForm, setAddressForm] = useState({
    fullName: "",
    phoneNumber: "",
    email: "",
    gstin: "",
    pincode: "",
    area: "",
    city: "",
    state: "",
  });

  useEffect(() => {
    const saved = localStorage.getItem("user_address");
    if (saved) {
      const parsed = JSON.parse(saved);
      setAddressForm(parsed);
      setSelectedAddress(parsed);
    }

    const fetchAddresses = async () => {
      try {
        const token = await getToken();
        const res = await fetch(
          "/api/user/address?phone=" + encodeURIComponent(parsed?.phoneNumber || ""),
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        const data = await res.json();
        if (data.success && Array.isArray(data.addresses)) {
          setSavedAddresses(data.addresses);
        }
      } catch (err) {
        console.error("Failed to fetch saved addresses", err);
      }
    };

    if (getToken) fetchAddresses();
  }, [getToken]);

  // Validation helpers
  const validateEmail = (email) =>
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

  const validateGSTIN = (gstin) =>
    gstin === "" || /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/.test(gstin);

  const validatePhone = (phone) =>
    /^\d{10}$/.test(phone);

  // Update address form & local cache
  const handleAddressChange = (field, value) => {
    const updated = { ...addressForm, [field]: value };
    setAddressForm(updated);
    localStorage.setItem("user_address", JSON.stringify(updated));
  };

  // Save or update address in backend
  const handleSubmitAddress = async (e) => {
    e.preventDefault();

    const requiredFields = [
      "fullName",
      "phoneNumber",
      "email",
      "pincode",
      "area",
      "city",
      "state",
    ];
    for (const field of requiredFields) {
      if (!addressForm[field]) {
        return toast.error(`Please fill the ${field}`);
      }
    }
    if (!validateEmail(addressForm.email)) {
      return toast.error("Please enter a valid email");
    }
    if (!validateGSTIN(addressForm.gstin)) {
      return toast.error("Please enter a valid GSTIN or leave it blank");
    }
    if (!validatePhone(addressForm.phoneNumber)) {
      return toast.error("Please enter a valid 10-digit phone number");
    }

    try {
      const token = await getToken();

      const res = await fetch("/api/user/address", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(addressForm),
      });
      const data = await res.json();
      if (!data.success)
        throw new Error(data.message || "Failed to update address");

      setSavedAddresses((prev) => {
        const index = prev.findIndex((addr) => addr._id === data.address._id);
        if (index >= 0) {
          const updated = [...prev];
          updated[index] = data.address;
          return updated;
        } else {
          return [...prev, data.address];
        }
      });

      localStorage.setItem("user_address", JSON.stringify(addressForm));
      setSelectedAddress(data.address);
      setShowAddressModal(false);
      toast.success("Address saved successfully!");
    } catch (err) {
      toast.error(err.message || "Failed to save address");
    }
  };

  const selectSavedAddress = (address) => {
    setSelectedAddress(address);
    setAddressForm(address);
    localStorage.setItem("user_address", JSON.stringify(address));
  };

  const formatINR = (amount) =>
    new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
    }).format(amount);

  const handlePlaceOrder = async () => {
    if (!selectedAddress) return toast.error("Please add your address first");

    const cartArray = Object.entries(cartItems).map(([key, qty]) => {
      const [productId, variantId, colorName] = key.split("|");
      return { productId, variantId, colorName, quantity: qty };
    });

    if (cartArray.length === 0) return toast.error("Cart is empty");

    try {
      setLoading(true);
      const token = await getToken();

      const res = await fetch("/api/order/create", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          items: cartArray,
          address: selectedAddress,
          paymentMethod,
        }),
      });

      const data = await res.json();

      if (!data.success) throw new Error(data.message || "Order failed");

      toast.success("Order placed successfully!");
      setCartItems({});
      router.push("/order-placed");
    } catch (err) {
      toast.error(err.message || "Failed to place order");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6 w-full max-w-lg mx-auto font-sans">
      <h2 className="text-xl font-semibold mb-4 text-gray-800">Order Summary</h2>

      {/* Address Section */}
      <div className="mb-5">
        <div className="flex justify-between items-center mb-2">
          <h3 className="text-lg font-medium text-gray-700">Delivery Address</h3>
          <button
            onClick={() => setShowAddressModal(true)}
            className="text-sm text-[#e80808] font-semibold hover:underline"
          >
            + Add / Edit Address
          </button>
        </div>

        {selectedAddress ? (
          <div className="border rounded-lg p-4 text-sm text-gray-800 bg-gray-50 mb-4">
            <p className="font-medium">{selectedAddress.fullName}</p>
            <p>{selectedAddress.phoneNumber}</p>
            <p>{selectedAddress.email}</p>
            <p>
              {selectedAddress.area}, {selectedAddress.city} - {selectedAddress.pincode}
            </p>
            <p>{selectedAddress.state}</p>
            <p>GSTIN: {selectedAddress.gstin || "N/A"}</p>
          </div>
        ) : (
          <p className="text-sm text-gray-500 mb-4">No address selected</p>
        )}

        {savedAddresses.length > 0 && (
          <>
            <h4 className="font-semibold text-gray-700 mb-2">Saved Addresses</h4>
            <ul className="max-h-40 overflow-auto space-y-2 border border-gray-300 rounded p-3 text-sm">
              {savedAddresses.map((addr) => (
                <li
                  key={addr._id}
                  onClick={() => selectSavedAddress(addr)}
                  className={`cursor-pointer p-2 rounded ${
                    selectedAddress?._id === addr._id
                      ? "bg-[#e80808] text-white"
                      : "hover:bg-gray-100"
                  }`}
                >
                  <p className="font-medium">{addr.fullName}</p>
                  <p>{addr.phoneNumber}</p>
                  <p>{addr.email}</p>
                  <p>
                    {addr.area}, {addr.city} - {addr.pincode}
                  </p>
                  <p>{addr.state}</p>
                  <p>GSTIN: {addr.gstin || "N/A"}</p>
                </li>
              ))}
            </ul>
          </>
        )}
      </div>

      {/* Payment Method Select */}
      <div className="mb-4">
        <label className="text-sm font-medium block mb-1 text-gray-600">
          Payment Method
        </label>
        <select
          value={paymentMethod}
          onChange={(e) => setPaymentMethod(e.target.value)}
          className="w-full border p-2 rounded text-sm"
        >
          <option value="razorpay">Pay Online (Razorpay)</option>
          <option value="cod">Cash on Delivery</option>
        </select>
      </div>

      {/* Total Price */}
      <div className="border-t pt-4 mt-4 text-sm text-gray-700">
        <div className="flex justify-between mb-2">
          <span>Items ({getCartCount()})</span>
          <span>{formatINR(getCartAmount())}</span>
        </div>
        <div className="flex justify-between font-semibold text-base">
          <span>Total</span>
          <span>{formatINR(getCartAmount())}</span>
        </div>
      </div>

      {/* Place Order Button */}
      <button
        onClick={handlePlaceOrder}
        disabled={loading}
        className="mt-6 w-full bg-[#e80808] text-white py-3 rounded font-semibold hover:bg-red-700 transition"
      >
        {loading ? "Placing Order..." : "Place Order"}
      </button>

      {/* Address Modal Popup */}
      {showAddressModal && (
        <div
          className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="addressModalTitle"
        >
          <div className="bg-white p-6 rounded-lg max-w-lg w-full relative shadow-lg">
            <button
              onClick={() => setShowAddressModal(false)}
              className="absolute top-3 right-3 text-gray-600 hover:text-black text-xl"
              aria-label="Close modal"
            >
              &times;
            </button>
            <h3 id="addressModalTitle" className="text-lg font-semibold mb-4">
              Add / Edit Address
            </h3>
            <form onSubmit={handleSubmitAddress} className="space-y-3">
              {[
                { key: "fullName", label: "Full Name", required: true },
                { key: "phoneNumber", label: "Phone Number", required: true },
                { key: "email", label: "Email", required: true, type: "email" },
                { key: "gstin", label: "GSTIN", required: false, type: "text" },
                { key: "pincode", label: "Pin Code", required: true },
                { key: "area", label: "Area and Street", required: true },
                { key: "city", label: "City", required: true },
                { key: "state", label: "State", required: true },
              ].map(({ key, label, required, type = "text" }) => (
                <input
                  key={key}
                  required={required}
                  type={type}
                  placeholder={label}
                  className="w-full border px-3 py-2 rounded text-sm"
                  value={addressForm[key] || ""}
                  onChange={(e) => handleAddressChange(key, e.target.value)}
                />
              ))}
              <button
                type="submit"
                className="w-full bg-[#e80808] text-white py-2 mt-2 rounded hover:bg-red-800"
              >
                Save Address
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default OrderSummary;
