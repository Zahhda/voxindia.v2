'use client';

import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { useEffect, useState } from "react";
import axios from "axios";

const AddAddress = () => {
  const [userName, setUserName] = useState("");
  const [userPhone, setUserPhone] = useState("");
  const [userAddresses, setUserAddresses] = useState([]);
  const [selectedAddressId, setSelectedAddressId] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // New Address Form state
  const [newAddress, setNewAddress] = useState({
    fullName: "",
    phoneNumber: "",
    email: "",
    gstin: "",
    pincode: "",
    area: "",
    city: "",
    state: "",
  });
  const [adding, setAdding] = useState(false);

  // Load user info and addresses on mount
  useEffect(() => {
    const name = sessionStorage.getItem("user_name") || "";
    const phone = sessionStorage.getItem("user_phone") || "";

    setUserName(name);
    setUserPhone(phone);

    if (!phone) {
      setError("User phone not found. Please login first.");
      return;
    }

    setLoading(true);
    axios
      .get(`/api/user/addresses?phone=${encodeURIComponent(phone)}`)
      .then((res) => {
        if (res.data.success) {
          setUserAddresses(res.data.addresses || []);

          // Load selected address id or pick first
          const savedSelected = localStorage.getItem("selectedAddress");
          if (savedSelected) {
            try {
              const savedAddr = JSON.parse(savedSelected);
              setSelectedAddressId(savedAddr._id || null);
            } catch {
              setSelectedAddressId(res.data.addresses[0]?._id || null);
              localStorage.setItem(
                "selectedAddress",
                JSON.stringify(res.data.addresses[0])
              );
            }
          } else if (res.data.addresses.length > 0) {
            setSelectedAddressId(res.data.addresses[0]._id);
            localStorage.setItem(
              "selectedAddress",
              JSON.stringify(res.data.addresses[0])
            );
          }
        } else {
          setError(res.data.message || "Failed to load addresses");
        }
      })
      .catch((err) => {
        setError(err.message || "Failed to load addresses");
      })
      .finally(() => {
        setLoading(false);
      });
  }, []);

  // When user picks a different address, update localStorage and state
  const handleSelectAddress = (addressId) => {
    setSelectedAddressId(addressId);
    const selected = userAddresses.find((addr) => addr._id === addressId);
    if (selected) {
      localStorage.setItem("selectedAddress", JSON.stringify(selected));
    }
  };

  // Validation helpers
  const validateEmail = (email) =>
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

  const validateGSTIN = (gstin) =>
    gstin === "" || /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/.test(gstin);

  const validatePhone = (phone) =>
    /^\d{10}$/.test(phone);

  // Handle new address form input changes
  const handleNewAddressChange = (field, value) => {
    setNewAddress((prev) => ({ ...prev, [field]: value }));
  };

  // Submit new address to backend
  const handleAddAddress = async (e) => {
    e.preventDefault();

    // Validation
    const requiredFields = ["fullName", "phoneNumber", "email", "pincode", "area", "city", "state"];
    for (const field of requiredFields) {
      if (!newAddress[field]) {
        alert(`Please fill the ${field} field.`);
        return;
      }
    }

    if (!validateEmail(newAddress.email)) {
      alert("Please enter a valid email.");
      return;
    }
    if (!validateGSTIN(newAddress.gstin)) {
      alert("Please enter a valid GSTIN or leave it blank.");
      return;
    }
    if (!validatePhone(newAddress.phoneNumber)) {
      alert("Please enter a valid 10-digit phone number.");
      return;
    }

    // Add phone from session if not filled
    if (!newAddress.phoneNumber) {
      newAddress.phoneNumber = userPhone;
    }

    try {
      setAdding(true);
      const res = await axios.post("/api/user/address", newAddress);
      if (res.data.success) {
        // Add new address to list & select it
        setUserAddresses((prev) => [...prev, res.data.address]);
        setSelectedAddressId(res.data.address._id);
        localStorage.setItem("selectedAddress", JSON.stringify(res.data.address));
        setNewAddress({
          fullName: "",
          phoneNumber: userPhone,
          email: "",
          gstin: "",
          pincode: "",
          area: "",
          city: "",
          state: "",
        });
        alert("Address added successfully!");
      } else {
        alert(res.data.message || "Failed to add address.");
      }
    } catch (err) {
      alert(err.message || "Failed to add address.");
    } finally {
      setAdding(false);
    }
  };

  return (
    <>
      <Navbar />
      <main
        className="min-h-screen p-10 bg-gray-50"
        style={{
          fontFamily:
            "'Inter', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif",
        }}
      >
        <h1 className="text-3xl font-semibold mb-6 text-gray-900">
          Your Profile Info & Addresses
        </h1>

        <div className="max-w-md bg-white p-6 rounded-lg shadow space-y-6 mx-auto">
          <div>
            <label className="block font-semibold text-gray-700 mb-1">Name:</label>
            <p className="text-gray-900">{userName || "Not logged in"}</p>
          </div>
          <div>
            <label className="block font-semibold text-gray-700 mb-1">Phone:</label>
            <p className="text-gray-900">{userPhone || "Not logged in"}</p>
          </div>

          <div>
            <label className="block font-semibold text-gray-700 mb-3">
              Select Saved Shipping Address
            </label>
            {loading ? (
              <p className="text-gray-500 italic">Loading addresses...</p>
            ) : error ? (
              <p className="text-red-600 italic">{error}</p>
            ) : userAddresses.length === 0 ? (
              <p className="text-gray-500 italic">No saved addresses found.</p>
            ) : (
              <ul className="space-y-3 max-h-72 overflow-y-auto border border-gray-300 rounded-lg p-3">
                {userAddresses.map((addr) => (
                  <li
                    key={addr._id}
                    className={`hover:bg-gray-100 rounded p-2 transition cursor-pointer ${
                      selectedAddressId === addr._id ? "bg-[#e80808] text-white" : ""
                    }`}
                  >
                    <label className="flex items-start gap-3 cursor-pointer">
                      <input
                        type="radio"
                        name="selectedAddress"
                        checked={selectedAddressId === addr._id}
                        onChange={() => handleSelectAddress(addr._id)}
                        className="mt-1 cursor-pointer"
                      />
                      <div>
                        <p className="font-semibold text-gray-900">{addr.fullName}</p>
                        <p className="text-gray-700">{addr.phoneNumber}</p>
                        {addr.email && <p className="text-gray-700">{addr.email}</p>}
                        <p className="text-gray-700">
                          {addr.area}, {addr.city}, {addr.state} - {addr.pincode}
                        </p>
                      </div>
                    </label>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Add New Address Form */}
          <div className="mt-10 border-t pt-6">
            <h2 className="text-xl font-semibold mb-4">Add New Address</h2>
            <form onSubmit={handleAddAddress} className="space-y-3">
              <input
                type="text"
                required
                placeholder="Full Name"
                value={newAddress.fullName}
                onChange={(e) => handleNewAddressChange("fullName", e.target.value)}
                className="w-full border px-3 py-2 rounded text-sm"
              />
              <input
                type="tel"
                required
                placeholder="Phone Number"
                value={newAddress.phoneNumber}
                onChange={(e) => handleNewAddressChange("phoneNumber", e.target.value)}
                className="w-full border px-3 py-2 rounded text-sm"
                maxLength={10}
              />
              <input
                type="email"
                required
                placeholder="Email"
                value={newAddress.email}
                onChange={(e) => handleNewAddressChange("email", e.target.value)}
                className="w-full border px-3 py-2 rounded text-sm"
              />
              <input
                type="text"
                placeholder="GSTIN (optional)"
                value={newAddress.gstin}
                onChange={(e) => handleNewAddressChange("gstin", e.target.value)}
                className="w-full border px-3 py-2 rounded text-sm"
              />
              <input
                type="text"
                required
                placeholder="Pin Code"
                value={newAddress.pincode}
                onChange={(e) => handleNewAddressChange("pincode", e.target.value)}
                className="w-full border px-3 py-2 rounded text-sm"
              />
              <input
                type="text"
                required
                placeholder="Area and Street"
                value={newAddress.area}
                onChange={(e) => handleNewAddressChange("area", e.target.value)}
                className="w-full border px-3 py-2 rounded text-sm"
              />
              <input
                type="text"
                required
                placeholder="City"
                value={newAddress.city}
                onChange={(e) => handleNewAddressChange("city", e.target.value)}
                className="w-full border px-3 py-2 rounded text-sm"
              />
              <input
                type="text"
                required
                placeholder="State"
                value={newAddress.state}
                onChange={(e) => handleNewAddressChange("state", e.target.value)}
                className="w-full border px-3 py-2 rounded text-sm"
              />
              <button
                type="submit"
                disabled={adding}
                className="w-full bg-[#e80808] text-white py-2 mt-2 rounded hover:bg-red-800"
              >
                {adding ? "Adding..." : "Add Address"}
              </button>
            </form>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
};

export default AddAddress;
