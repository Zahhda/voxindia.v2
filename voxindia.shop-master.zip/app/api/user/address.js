import connectDB from "@/config/db";
import Address from "@/models/Address";

export async function POST(req) {
  await connectDB();

  const body = await req.json();
  const { fullName, phoneNumber, email, gstin, pincode, area, city, state } = body;

  if (!fullName || !phoneNumber || !email || !pincode || !area || !city || !state) {
    return new Response(
      JSON.stringify({ success: false, message: "Missing required fields" }),
      { status: 400, headers: { "Content-Type": "application/json" } }
    );
  }

  try {
    const newAddress = new Address({ fullName, phoneNumber, email, gstin, pincode, area, city, state });
    await newAddress.save();

    return new Response(
      JSON.stringify({ success: true, address: newAddress }),
      { status: 201, headers: { "Content-Type": "application/json" } }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ success: false, message: error.message }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }
}
